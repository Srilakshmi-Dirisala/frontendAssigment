import React from 'react'

function Focter() {
    return (
        <div>Focter</div>
    )
}

export default Focter